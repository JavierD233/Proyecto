package ejercicio1;

public class reto1 {

	public static void main(String[] args) {
		int num1=2,num2=5,num3=10,mayor=0;
		if(num1>num2 && num1>num3) {
			mayor=num1;
		}else if(num2>num1 && num2>num3) {
			mayor=num2;
		}else if(num3>num1 && num3>num2) {
			mayor=num3;
		}
		System.out.println("El número mayor es: "+mayor);

	}

}
