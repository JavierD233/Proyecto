package ejercicio3;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		Scanner leer=new Scanner(System.in);
		double num1,num2,suma,resta,multi,division;
		char operador;
		int opt=1;
		System.out.println("CALCULADORA");
		do {
			System.out.println("Ingrese 2 números: "); 
			num1=leer.nextDouble();
			num2=leer.nextDouble();
			System.out.println("Suma           (+)");
			System.out.println("Resta          (-)");
			System.out.println("Multiplicación (*)");
			System.out.println("División       (/)");
			System.out.println("Ingrese la opción deseada: "); operador=leer.next().charAt(0);
			
			if(operador=='+') {
				suma=num1+num2;
				System.out.println("La suma es: "+suma);
			}
			else if(operador=='-') {
				resta=num1-num2;
				System.out.println("La resta es: "+resta);
			}
			else if(operador=='*') {
				multi=num1*num2;
				System.out.println("La multiplicación es: "+multi);
			}
			else if(operador=='/') {
				if(num2==0) {
					System.out.println("ERROR, no se puede dividir por cero"); continue;
				}
				division=num1/num2;
				System.out.println("La división es: "+division);
			}
			else {
				System.out.println("Opción no existente");
			}
			System.out.println("Desea realizar otra operación? (si=1, no=0)"); opt=leer.nextInt();
		}while(opt!=0);
		
		

	}

}
