
public class user {
	private String user;
	private String psw;
	
	public user() {
		user="admin";
		psw="admin123";
	}
	
	public boolean validar(String a,String b) {
		if(a.equals(user) && b.equals(psw)) {
			return true;
		}else {
			return false;
		}
	}
}
