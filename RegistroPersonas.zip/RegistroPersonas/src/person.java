
public class person {
	public String name;
	public int age;
	public long phone;
	public int dni;
	
	public person() {
		name="";
		age=0;
		phone=0L;
		dni=0;
	}
	public person(String n,int a,long p,int d) {
		this.name=n;
		this.age=a;
		this.phone=p;
		this.dni=d;
	}
	public String info() {
		return String.format("%s, %d años, (+593)%d, DNI: %d",name,age,phone,dni);
	}
}
