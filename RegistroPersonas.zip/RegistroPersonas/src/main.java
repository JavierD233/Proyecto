import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		Scanner leer=new Scanner(System.in);
		String usuario,psw,name;
		int n,age,dni;
		long phone;
		char opt=' ';
		boolean validar,lleno=false,encontrado=false,encontrado2=false;
		
		System.out.println("Ingrese el usuario: ");
		usuario=leer.next();
		System.out.println("Ingrese la contraseña: ");
		psw=leer.next();
		user u=new user();
		validar=u.validar(usuario, psw);
		
		if(validar==true) {
			System.out.println("Número de personas: ");
			n=leer.nextInt();
			person[] persons=new person[n];
			do {
				System.out.println("Registro           [r]");
				System.out.println("Listar por nombres [n]");
				System.out.println("Buscar             [s]");
				System.out.println("Actualizar         [u]");
				System.out.println("Salir              [x]");
				System.out.println("Ingrese la opción deseada: ");
				opt=leer.next().charAt(0);
				if((opt=='n'||opt=='s'||opt=='u') && (lleno==false)) {
					System.out.println("Error, registro vacio");
					continue;
				}
				if(opt=='r' && lleno==false) {
					for(int i=0; i<persons.length; i++) {
						System.out.println("Persona "+(i+1));
						leer.nextLine();
						System.out.println("Nombre: "); name=leer.nextLine();
						System.out.println("Edad: "); age=leer.nextInt();
						System.out.println("Teléfono: "); phone=leer.nextLong();
						System.out.println("Cédula: "); dni=leer.nextInt();
						persons[i]=new person(name,age,phone,dni);
					}
					lleno=true; 
				}else if(opt=='r' && lleno==true) {
					System.out.println("Error, registro lleno");
				}else if(opt=='n') {
					for(person p:persons) {
						System.out.println(p.name);
					}
				}else if(opt=='s') {
					System.out.println("Ingrese el DNI: "); dni=leer.nextInt();
					for(person p:persons) {
						if(p.dni==dni) {
							System.out.println(p.info());
							encontrado=true;
							break;
						}
					}
					if(encontrado==false) {
						System.out.println("No existe el registro");
						continue;
					}
				}else if(opt=='u') {
					System.out.println("Ingrese el DNI: "); dni=leer.nextInt();
					for(person p:persons) {
						if(p.dni==dni) {
							leer.nextLine();
							System.out.println("Nombre: "); p.name=leer.nextLine();
							System.out.println("Edad: "); p.age=leer.nextInt();
							System.out.println("Teléfono: "); p.phone=leer.nextLong();
							System.out.println("Cédula: "); p.dni=leer.nextInt();
							System.out.println("Los datos se han actualizado correctamente");
							encontrado2=true;
							break;
						}
					}
					if(encontrado2==false) {
						System.out.println("No existe el registro");
						continue;
					}
				}else if(opt=='x') {
					break;
				}else {
					System.out.println("Opción no existente");
				}
			}while(opt!='x');
		}else {
			System.out.println("Usuario o contraseña incorrecta");
		}
	}

}
