
public class main {

	public static void main(String[] args) {
		int notaFija=10;
		String resultado = (notaFija >= 7) ? "APROBADO" : "REPROBADO";
		System.out.println(resultado);
		
	}

}
