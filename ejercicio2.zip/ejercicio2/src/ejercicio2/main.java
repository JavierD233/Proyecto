package ejercicio2;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		Scanner leer=new Scanner(System.in);
		int num,aux=0,suma=0;
		System.out.println("Ingrese un valor entero: "); num=leer.nextInt();
		while(aux<=num) {
			if(aux%2==0) {
				suma+=aux;
			}
			aux++;
		}
		System.out.println("Resultado total: "+suma);

	}

}
